

import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'global.dart';



void main() => runApp(const Escolha());


class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  static const String _title = 'Amostra';
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(title: const Text(_title)),
        body: const Center(

          child: MyStatefulWidget(),
        ),
      ),
    );
  }
}
// ***************** TELA 02 RADIO 90 95 99 **********************************


enum SingingCharacter { noventa, noventaecinco, noventaenove, nada}
class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({Key? key}) : super(key: key);

  @override

  State<MyStatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  double confZ = 0;

  SingingCharacter? character3 = SingingCharacter.nada;

  var _raisedButtonStyle;

  set raisedButtonStyle(raisedButtonStyle) {
    _raisedButtonStyle = raisedButtonStyle;
  }


//  @override
  Widget build(BuildContext context) {
    // ignore: unnecessary_new
    //_MyStatefulWidgetState conf = new _MyStatefulWidgetState();
    //final characterGlobal = GlobalKey<FormState>();

    return ListView(

    children: <Widget>[
          Text('Escolha o intervalo de confiança da amostra',
              style: DefaultTextStyle.of(context).style.apply(fontSizeFactor: 1.5)),
          ListTile(
            title: Text('90%  valor de  Z = 1.654',
                style: DefaultTextStyle.of(context).style.apply(fontSizeFactor: 1.5)),
            leading: Radio<SingingCharacter>(
              value: SingingCharacter.noventa,
              groupValue: character3,
              onChanged: (SingingCharacter? value) {
                setState(() {
                  character3 = value;
                  Global.changeDouble(1.654);
                  print(confZ);
                });
              },
            ),
          ),
          ListTile(
            title: Text('95%   valor de  Z = 1.960',
                style: DefaultTextStyle.of(context).style.apply(fontSizeFactor: 1.5)),
            leading: Radio<SingingCharacter>(
              value: SingingCharacter.noventaecinco,
              groupValue: character3,
              onChanged: (SingingCharacter? value) {
                setState(() {
                  character3 = value;
                  Global.changeDouble(1.96);
                  // prints para debug em tempo de execução
                  print(Global.confZ);
                  print('Global.characterGlobal');

                });
              },
            ),
          ),
          ListTile(
            title: Text('99%   valor de  Z = 2.575',
                style: DefaultTextStyle.of(context).style.apply(fontSizeFactor: 1.5)),
            leading: Radio<SingingCharacter>(
              value: SingingCharacter.noventaenove,
              groupValue: character3,
              onChanged: (SingingCharacter? value) {
                setState(() {
                  character3 = value;
                  Global.changeDouble(2.575);
                  // print para debug
                  print(Global.confZ);

                });
              },

            ),
          ),

      // Operador ternário (condicional dentro de um Widget)

                 Global.characterGlobal == 'SingingCharacter2.escolha1'? const MyCustomForm()
                     :const MyCustomForm2(),


          ElevatedButton(
            style: _raisedButtonStyle,
            onPressed: () async => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const Escolha()),
            ),
            child: const Text("Novo Calculo"),
          )
        ]
    );
  }


  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('_raisedButtonStyle', _raisedButtonStyle));
  }
}



//************************** TELA INICIAL ESCOLHA *****************************
class Escolha extends StatelessWidget {
  const Escolha({Key? key}) : super(key: key);
  static const String _title = 'Amostra';
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(title: const Text(_title)),
        body: const Center(
          child: MyStatefulWidget2(),
        ),
      ),
    );
  }
}
enum SingingCharacter2 { escolha1, escolha2, nada }
class MyStatefulWidget2 extends StatefulWidget {
  const MyStatefulWidget2({Key? key}) : super(key: key);

  @override
  State<MyStatefulWidget2> createState() => _MyStatefulWidgetState2();
}
// ********************** ENTRADA DE DADOS **************************
class _MyStatefulWidgetState2 extends State<MyStatefulWidget2> {
  SingingCharacter2? _opcao = SingingCharacter2.nada;
  //final _characterGlobal = GlobalKey<FormState>();
  String characterGlobal = "";
  @override
  Widget build(BuildContext context) {

    return Column(
        children: <Widget>[


          Text('Calcular o tamanho da Amostra, Informando o Tamanho da População, a Margem de Erro e o Grau de Confiança',
              style: DefaultTextStyle.of(context).style.apply(fontSizeFactor: 1.5)),
          ListTile(
            title: Text('Calcular o tamanho da Amostra',
                style: DefaultTextStyle.of(context).style.apply(fontSizeFactor: 1.5)),
            leading: Radio<SingingCharacter2>(
              value: SingingCharacter2.escolha1,
              groupValue: _opcao,
              onChanged: (SingingCharacter2? value) {
                setState(() {
                  _opcao = value;
                  Global.changeString('SingingCharacter2.escolha1');
                  print(Global.characterGlobal);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const MyApp()),
                  );
                });
              },
            ),
          ),

          Text('Calcular a Margem de Erro, informando o Grau de Confiança, População e o Tamanho da Amostra',
              style: DefaultTextStyle.of(context).style.apply(fontSizeFactor: 1.5)),
          ListTile(
            title: Text('Calcular o Erro Máximo de Estimativa', 
                style: DefaultTextStyle.of(context).style.apply(fontSizeFactor: 1.5)),
            leading: Radio<SingingCharacter2>(
              value: SingingCharacter2.escolha2,
              groupValue: _opcao,
              onChanged: (SingingCharacter2? value) {
                setState(() {
                  _opcao = value;
                  Global.changeString('SingingCharacter2.escolha2');
                  print(Global.characterGlobal);
                   Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const MyApp()),
                  );
                });
              },
            ),
          ),
        ]
    );
  }
}

//********************************************************

// Create a Form widget.
class MyCustomForm extends StatefulWidget {
  const MyCustomForm({super.key});

  @override
  MyCustomFormState createState() {

    return MyCustomFormState();
  }
}


class MyCustomFormState extends State<MyCustomForm> {

  //final characterGlobal = GlobalKey<FormState>();
  //final _formKey = GlobalKey<FormState>();
  final confZ = GlobalKey<FormState>();

  var amountController;
  String _amostraCal = "";
  int amostraCal = 0;
  double erromaximo = 0;
  double amostra = 0;
  int populacao = 0;



  @override
  Widget build(BuildContext context) {

   return Form(

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          TextFormField(
              cursorColor: Colors.indigoAccent,
              keyboardType: TextInputType.number,
              onChanged: (value) {
                  populacao = int.parse(value);
                  print(value);
              },

              decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Universo a ser Pesquisado",
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red
                      )
                  ),
                  labelText: "Tamanho da População",
                  labelStyle: TextStyle(color: Colors.black87,fontSize: 22.0,
                ),
             )
          ),

            TextFormField(
                 cursorColor: Colors.lightGreen,
                 keyboardType: TextInputType.number,
                 onChanged: (value) {
                    erromaximo = double.parse(value);
                    print(value);
                  },
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: "exemplo para 2% entre 2",
                    focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                            color: Colors.lightGreen
                        )
                    ),
                    labelText: "Margem de Erro para + ou -",
                    labelStyle: TextStyle(color: Colors.black87, fontSize: 22.0,
                    ),
                )
            ),

          Padding(
            padding: const EdgeInsets.symmetric(vertical: 26.0),
            child: ElevatedButton(
              onPressed: () async {

                amostra = tamanhoAmostra(populacao, erromaximo, Global.confZ);
                print(amostra);
                amostraCal = amostra.round();
                _amostraCal = amostraCal.toString();
                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(

                      title: const Text('Tamanho da Amostra'),
                      // Retrieve the text the that user has entered by using the
                      // TextEditingController.
                      content: Text('Amostra: $_amostraCal',
                          style: const TextStyle(fontSize: 23, fontFamily: 'Future',color: Colors.red)),
                      titleTextStyle: const TextStyle(color: Colors.indigo,fontSize: 22.0),
                      actions: <Widget>[

                        TextButton(
                          onPressed: () => Navigator.pop(context, 'OK'),
                          child: const Text('Fechar', style: TextStyle(fontSize: 23)),
                        ),
                      ],
                    );
                  },
                );
              },
              child: const Text('Calcular'),
            ),
          )
        ],
      ),
    );
  }
}

//********************** tempo **************************

double tamanhoAmostra(int populacao, double erromaximo, double z) {

  double erroMax = (erromaximo/100);
  double amostra = 0;

  if(populacao <= 100000){
    // amostra para populações até 100000 habitantes
    amostra = (populacao*0.5*0.5*pow(z,2))/((0.5*0.5*pow(z,2))+(populacao-1)*pow(erroMax,2));
  }else{
    // amostra para populações maiores que 100000 habitantes
    amostra = (0.5*0.5*pow(z,2))/pow(erroMax,2);
  }
   return amostra;
 }



//********************************************************

// Create a Form widget.
class MyCustomForm2 extends StatefulWidget {
  const MyCustomForm2({super.key});

  @override
  MyCustomFormState2 createState() {

    return MyCustomFormState2();
  }
}

// Create a corresponding State class.
// This class holds data related to the form.
class MyCustomFormState2 extends State<MyCustomForm2> {

  final characterGlobal = GlobalKey<FormState>();
  //final _formKey = GlobalKey<FormState>();
  final confZ = GlobalKey<FormState>();

  var amountController;
  String _erromaximo = "";
  double erromaximo = 0;
  int amostra = 0;
  int populacao = 0;



  @override
  Widget build(BuildContext context) {
   
    return Form(


      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          TextFormField(
              cursorColor: Colors.teal,
              keyboardType: TextInputType.number,
              onChanged: (value) {
                populacao = int.parse(value);
                print(value);
              },
              decoration: const InputDecoration(
                border: OutlineInputBorder(
                ),
                hintText: "Universo a ser Pesquisado",
                focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                        color: Colors.amber
                    )
                ),
                labelText: "Tamanho da População",
                labelStyle: TextStyle(color: Colors.black,fontSize: 19.0,
                ),
              )

          ),

          TextFormField(

              cursorColor: Colors.teal,
              keyboardType: TextInputType.number,
              onChanged: (value) {
                amostra = int.parse(value);
                print(value);
              },
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: " ",
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                        color: Colors.amber
                    )
                  ),
                labelText: "Tamanho da Amostra",
                labelStyle: TextStyle(color: Colors.black, fontSize: 19.0,
                ),
              )
          ),

          Padding(
            padding: const EdgeInsets.symmetric(vertical: 26.0),
            child: ElevatedButton(
              onPressed: () async {

                erromaximo = erroAmostral(populacao, amostra, Global.confZ);
                print(erromaximo);

                _erromaximo = erromaximo.toStringAsFixed(2);
                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(

                      title: const Text('Margem de Erro'),
                      content: Text('Erro: $_erromaximo para + ou -',
                          style: const TextStyle(fontSize: 23, fontFamily: 'Future')),
                      titleTextStyle: const TextStyle(color: Colors.teal,fontSize: 23.0),
                      actions: <Widget>[

                        TextButton(
                          onPressed: () => Navigator.pop(context, 'OK'),
                          child: const Text('Fechar', style: TextStyle(fontSize: 23)),
                        ),
                      ],
                    );
                  },
                );
              },
              child: const Text('Calcular'),
            ),
          )
        ],
      ),
    );
  }
}



double erroAmostral(int populacao, int amostra, double z) {

  double erroMax = 0;

  if(populacao <= 100000){
    // erro máximo da amostra para populações até 100000 habitantes
    erroMax = 100*sqrt(((populacao*0.5*0.5*pow(z,2))-amostra*(0.5*0.5*pow(z,2)))/((populacao-1)*(amostra)));
    print(erroMax);
  }else{
    // erro para populações maiores que 100000 habitantes
    erroMax = 100*sqrt((0.5*0.5*pow(z,2))/amostra);
  }
  return erroMax;
}
