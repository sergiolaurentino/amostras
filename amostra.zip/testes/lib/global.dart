class Global {
  static double confZ = 0;
  static String characterGlobal = '';

  static printString() {
    print(characterGlobal);
  }

  static printDouble() {
    print(confZ);
  }
  static changeDouble (double z)  {
    confZ = z;
    print(confZ);
  }
  static changeString (String c) {
    characterGlobal = c;
    print(characterGlobal);
  }
}