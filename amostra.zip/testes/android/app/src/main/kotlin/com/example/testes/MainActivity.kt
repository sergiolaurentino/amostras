package com.example.testes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
